﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.ComponentModel;
using System.IO;
using System.Security.Cryptography;

namespace test
{
    class Program
    {
        [DllImport("kernel32.dll")] static extern void Sleep(uint dwMilliseconds);
        static void Main(string[] args)
        {
            Console.WriteLine("working...");
            Sleep(60000);
        }
    }
}
